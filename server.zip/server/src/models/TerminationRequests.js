import mongoose from 'mongoose';

const terminationRequestSchema = new mongoose.Schema(
  {
    contract: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Contract',
      required: true,
    },
    requestedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    requestedDate: {
      type: Date,
      required: true,
    },
    moveOutDate: {
      type: Date,
      required: true,
    },
    reason: {
      type: String,
      trim: true,
    },
    outstandingBalance: {
      type: Number,
      default: 0,
    },
    depositDeduction: {
      type: Number,
      default: 0,
    },
    depositRefund: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'completed'],
      default: 'pending',
    },
    processedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    completedAt: {
      type: Date,
      default: null,
    },

    // Theo dõi các bước thanh toán/hoàn cọc và xác nhận checkout cuối cùng.
    checkoutSettlement: {
      allocatedDeposit: { type: Number, default: 0 },
      paymentInvoiceIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Invoice' }],
      paymentRequestedAt: { type: Date, default: null },
      paymentRequestedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
      refundAmount: { type: Number, default: 0 },
      refundConfirmedAt: { type: Date, default: null },
      refundConfirmedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
      finalizedAt: { type: Date, default: null },
      finalizedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    },

    // Kết quả đối soát cuối cùng khi Manager xử lý checkout
    checkoutReconciliation: {
      billingMonth: { type: String, default: '' },
      electricity: {
        oldIndex: { type: Number, default: 0 },
        newIndex: { type: Number, default: 0 },
        used: { type: Number, default: 0 },
        unitPrice: { type: Number, default: 0 },
        amount: { type: Number, default: 0 },
      },
      water: {
        oldIndex: { type: Number, default: 0 },
        newIndex: { type: Number, default: 0 },
        used: { type: Number, default: 0 },
        unitPrice: { type: Number, default: 0 },
        amount: { type: Number, default: 0 },
      },
      previousDebtAmount: { type: Number, default: 0 },
      previousDebtInvoiceIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Invoice' }],
      assetAmount: { type: Number, default: 0 },
      utilityAmount: { type: Number, default: 0 },
      penalty: {
        applies: { type: Boolean, default: false },
        billingMonth: { type: String, default: '' },
        weekNumber: { type: Number, default: 0 },
        completedWeeks: { type: Number, default: 0 },
        weeklyRent: { type: Number, default: 0 },
        amount: { type: Number, default: 0 },
      },
      totalDeductions: { type: Number, default: 0 },
      depositAmount: { type: Number, default: 0 },
      depositRefund: { type: Number, default: 0 },
      additionalPayment: { type: Number, default: 0 },
      calculatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
      calculatedAt: { type: Date, default: null },
    },
  },
  {
    timestamps: true,
  },
);

const TerminationRequests = mongoose.model('TerminationRequest', terminationRequestSchema);

export default TerminationRequests;
