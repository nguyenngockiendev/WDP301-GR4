import mongoose from 'mongoose';

const roomSchema = new mongoose.Schema(
  {
    name: { type: String, trim: true },
    floor: { type: Number, default: 1, min: 0 },
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Property',
      required: true,
    },
    roomNumber: {
      type: String,
      required: true,
      trim: true,
    },
    area: {
      type: Number,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    maxTenants: {
      type: Number,
      default: 1,
    },
    tier: {
      type: String,
      enum: ['basic', 'standard', 'premium'],
      default: 'standard',
    },
    facilities: [
      {
        type: String,
        trim: true,
      },
    ],
    description: {
      type: String,
      trim: true,
    },
    images: [
      {
        type: String,
      },
    ],
    status: {
      type: String,
      enum: ['available', 'occupied', 'maintenance', 'reserved'],
      default: 'available',
    },
  },
  {
    timestamps: true,
  }
);

const Rooms = mongoose.model('Room', roomSchema);

export default Rooms;
