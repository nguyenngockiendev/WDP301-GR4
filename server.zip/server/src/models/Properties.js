import mongoose from 'mongoose';

const propertySchema = new mongoose.Schema(
  {
    image: { type: String, default: '' },
    district: { type: String, default: '' },
    code: { type: String, default: '' },
    totalFloors: { type: Number, default: 1 },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    address: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      trim: true,
      maxlength: 1000,
      default: '',
    },
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active',
    },
    utilityRate: {
      electricityPrice: {
        type: Number,
        default: 0,
      },
      waterPrice: {
        type: Number,
        default: 0,
      },
      effectiveFrom: { type: Date, default: Date.now },
    },
    contractPolicy: {
      paymentDueDay: {
        type: Number,
        default: 5,
      },
      paymentGraceDays: {
        type: Number,
        default: 3,
      },
      depositMonths: {
        type: Number,
        default: 1,
      },
      policyNote: {
        type: String,
        trim: true,
      },
    },
  },
  {
    timestamps: true,
  }
);

const Properties = mongoose.model('Property', propertySchema);

export default Properties;
